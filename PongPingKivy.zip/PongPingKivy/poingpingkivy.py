from kivy.app import App
from kivy.uix.widget import Widget
from kivy.core.window import Window
from kivy.properties import NumericProperty, ReferenceListProperty
from kivy.vector import Vector
from kivy.clock import Clock
from kivy.uix.label import Label
from kivy.graphics import Color, Rectangle, Ellipse

Window.maximize()  # Tela cheia

keys_pressed = set()  # teclas pressionadas


class PongPaddle(Widget):
    score = NumericProperty(0)

    def __init__(self, color=(1, 1, 1, 1), **kwargs):
        super().__init__(**kwargs)
        with self.canvas:
            Color(*color)
            self.rect = Rectangle(pos=self.pos, size=self.size)
        self.bind(pos=self.update_graphics, size=self.update_graphics)

    def update_graphics(self, *args):
        self.rect.pos = self.pos
        self.rect.size = self.size

    def move_up(self):
        if self.top < self.parent.height:
            self.y += 10

    def move_down(self):
        if self.y > 0:
            self.y -= 10


class PongBall(Widget):
    velocity_x = NumericProperty(6)
    velocity_y = NumericProperty(4)
    velocity = ReferenceListProperty(velocity_x, velocity_y)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        with self.canvas:
            Color(1, 1, 1)
            self.ellipse = Ellipse(pos=self.pos, size=self.size)
        self.bind(pos=self.update_graphics, size=self.update_graphics)

    def update_graphics(self, *args):
        self.ellipse.pos = self.pos
        self.ellipse.size = self.size

    def move(self):
        self.pos = Vector(*self.velocity) + self.pos


class PongGame(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.player1 = PongPaddle(color=(1, 0, 0, 1), size=(20, 120))   # vermelho
        self.player2 = PongPaddle(color=(0, 0.5, 1, 1), size=(20, 120))  # azul
        self.ball = PongBall(size=(25, 25))

        self.label1 = Label(text="P1: 0", font_size=32,
                            pos=(50, Window.height - 80), size_hint=(None, None))
        self.label2 = Label(text="P2: 0", font_size=32,
                            pos=(Window.width - 150, Window.height - 80), size_hint=(None, None))

        self.add_widget(self.player1)
        self.add_widget(self.player2)
        self.add_widget(self.ball)
        self.add_widget(self.label1)
        self.add_widget(self.label2)

        self.reset_positions()

        Window.bind(on_key_down=self.on_key_down)
        Window.bind(on_key_up=self.on_key_up)

        Clock.schedule_interval(self.update, 1 / 60)

    def reset_positions(self):
        # Coloca as raquetes nos lados certos
        self.player1.center_y = self.center_y
        self.player1.x = 20

        self.player2.center_y = self.center_y
        self.player2.right = self.width - 20

        self.ball.center = self.center
        self.ball.velocity = Vector(6, 4)

    def update(self, dt):
        # Movimento das raquetes
        if "w" in keys_pressed:
            self.player1.move_up()
        if "s" in keys_pressed:
            self.player1.move_down()
        if "up" in keys_pressed:
            self.player2.move_up()
        if "down" in keys_pressed:
            self.player2.move_down()

        self.ball.move()

        # Rebater nas bordas de cima e de baixo
        if self.ball.y <= 0 or self.ball.top >= self.height:
            self.ball.velocity_y *= -1

        # Rebater nas raquetes
        if self.ball.collide_widget(self.player1):
            self.ball.velocity_x *= -1
            self.ball.x = self.player1.right  # evitar bug de colar

        if self.ball.collide_widget(self.player2):
            self.ball.velocity_x *= -1
            self.ball.right = self.player2.x  # evitar bug de colar

        # Pontuação
        if self.ball.x < 0:
            self.player2.score += 1
            self.reset_positions()

        if self.ball.right > self.width:
            self.player1.score += 1
            self.reset_positions()

        # Atualiza os textos
        self.label1.text = f"P1: {self.player1.score}"
        self.label2.text = f"P2: {self.player2.score}"

    def on_key_down(self, window, key, scancode, codepoint, modifiers):
        keyname = Window._system_keyboard.keycode_to_string(key)
        if keyname:
            keys_pressed.add(keyname.lower())

    def on_key_up(self, window, key, scancode):
        keyname = Window._system_keyboard.keycode_to_string(key)
        if keyname:
            keys_pressed.discard(keyname.lower())


class PongApp(App):
    def build(self):
        return PongGame()


if __name__ == "__main__":
    PongApp().run()
