from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.utils import get_color_from_hex
from kivy.graphics import Color, Rectangle

# Importa as classes das telas adicionais
from screens.tela1 import Tela1
from screens.tela2 import Tela2
from screens.tela3 import Tela3
from screens.tela4 import Tela4
from screens.tela5 import Tela5

class HomeScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        with self.canvas.before:
            Color(rgb=get_color_from_hex('#2C3E50'))
            self.rect = Rectangle(size=self.size, pos=self.pos)
        
        self.bind(pos=self.update_rect, size=self.update_rect)
        
        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        
        titulo = Label(
            text='Tela Principal',
            font_size='32sp',
            size_hint=(1, 0.2),
            color=get_color_from_hex('#FFFFFF')
        )
        
        layout_botoes = BoxLayout(orientation='vertical', spacing=10)
        
        nomes_telas = ['Tela1', 'Tela2', 'Tela3', 'Tela4', 'Tela5']
        
        for nome_tela in nomes_telas:
            botao = Button(
                text=f'Ir para {nome_tela}',
                background_color=get_color_from_hex('#1ABC9C')
            )
            botao.bind(on_press=lambda instance, tela=nome_tela: self.mudar_tela(tela))
            layout_botoes.add_widget(botao)
            
        layout.add_widget(titulo)
        layout.add_widget(layout_botoes)
        
        self.add_widget(layout)
        
    def mudar_tela(self, nome_tela):
        self.manager.current = nome_tela
        
    def update_rect(self, instance, value):
        self.rect.pos = instance.pos
        self.rect.size = instance.size

class MobileApp(App):
    def build(self):
        sm = ScreenManager()
        
        sm.add_widget(HomeScreen(name='HomeScreen'))
        sm.add_widget(Tela1(name='Tela1'))
        sm.add_widget(Tela2(name='Tela2'))
        sm.add_widget(Tela3(name='Tela3'))
        sm.add_widget(Tela4(name='Tela4'))
        sm.add_widget(Tela5(name='Tela5'))
        
        return sm

if __name__ == '__main__':
    MobileApp().run()