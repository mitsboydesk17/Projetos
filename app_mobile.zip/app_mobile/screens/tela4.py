from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.utils import get_color_from_hex
from kivy.graphics import Color, Rectangle

class Tela4(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        with self.canvas.before:
            Color(rgb=get_color_from_hex('#F1C40F'))
            self.rect = Rectangle(size=self.size, pos=self.pos)
        
        self.bind(pos=self.update_rect, size=self.update_rect)

        layout = BoxLayout(orientation='vertical')
        
        titulo = Label(
            text='Tela 2',
            font_size='32sp',
            size_hint=(1, 0.2),
            color=get_color_from_hex('#FFFFFF')
        )
        
        botao_voltar = Button(
            text='Voltar para a página inicial',
            size_hint=(1, 0.2),
            background_color=get_color_from_hex('#F39C12')
        )
        botao_voltar.bind(on_press=self.voltar_para_home)
        
        layout.add_widget(titulo)
        layout.add_widget(Label(text='Conteúdo da Tela 4'))
        layout.add_widget(botao_voltar)
        
        self.add_widget(layout)
        
    def voltar_para_home(self, instance):
        self.manager.current = 'HomeScreen'
    
    def update_rect(self, instance, value):
        self.rect.pos = instance.pos
        self.rect.size = instance.size